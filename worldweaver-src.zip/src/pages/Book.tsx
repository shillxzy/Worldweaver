import { useState } from 'react'
import CoverArt from '../components/CoverArt'
import Header from '../components/Header'
import { useApp } from '../settings-context'
import type { Project } from '../types'

export default function Book({ p }: { p: Project }) {
  const { t } = useApp()
  const [open, setOpen] = useState(false)
  const [page, setPage] = useState(0)
  return (
    <>
      <Header title={t('s.book')} sub={open ? p.title : t('bk.closed')} />
      {!open ? (
        <div className="shelf">
          <button className="cover-art" onClick={() => setOpen(true)}><CoverArt p={p} big /></button>
        </div>
      ) : (
        <>
          <div className="paper">{p.pages[page]}<div className="pn">{page + 1} / {p.pages.length}</div></div>
          <div className="pager">
            <button className="link" disabled={page === 0} onClick={() => setPage(page - 1)}>{t('bk.prev')}</button>
            <button className="link" onClick={() => setOpen(false)}>{t('bk.close')}</button>
            <button className="link" disabled={page === p.pages.length - 1} onClick={() => setPage(page + 1)}>{t('bk.next')}</button>
          </div>
        </>
      )}
    </>
  )
}
