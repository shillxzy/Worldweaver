import Header from '../components/Header'
import { useApp } from '../settings-context'
import type { Project } from '../types'

export default function Timeline({ p }: { p: Project }) {
  const { t } = useApp()
  return (
    <>
      <Header title={t('s.timeline')} sub={t('tl.sub')} />
      <div className="timeline">
        {p.events.map((e) => (
          <div className="ev" key={e.title}>
            <small>{e.date}</small>
            <h3>{e.title}</h3>
            <p>{e.text}</p>
          </div>
        ))}
      </div>
    </>
  )
}
