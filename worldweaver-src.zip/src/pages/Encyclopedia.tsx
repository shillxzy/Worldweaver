import { useState } from 'react'
import Header from '../components/Header'
import Icon from '../components/Icon'
import { TYPES, TYPE_META } from '../data/projects'
import { useApp } from '../settings-context'
import type { Project } from '../types'
import { cssVars } from '../utils'

export default function Encyclopedia({ p }: { p: Project }) {
  const { t } = useApp()
  const [type, setType] = useState('Усе')
  const list = p.entries.filter((e) => type === 'Усе' || e.type === type)
  const label = (k: string) => t(k === 'Усе' ? 'type.all' : 'type.' + k)

  return (
    <>
      <Header title={t('s.encyclopedia')} sub={`${t('enc.sub')} «${p.title}».`} />
      <div className="tabs">
        {TYPES.map((k) => <button key={k} className={'tab' + (k === type ? ' on' : '')} onClick={() => setType(k)}>{label(k)}</button>)}
      </div>
      <div>
        {list.map((e) => {
          const m = TYPE_META[e.type]
          return (
            <div className="row" key={e.name} style={cssVars({ '--t': m.color })}>
              <div className="chip"><Icon n={m.icon} /></div>
              <h3>{e.name}</h3>
              <span className="tag">{label(e.type)}</span>
              <p>{e.desc}</p>
            </div>
          )
        })}
      </div>
    </>
  )
}
