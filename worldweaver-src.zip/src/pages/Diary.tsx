import Header from '../components/Header'
import { useApp } from '../settings-context'
import type { Project } from '../types'
import { cssVars } from '../utils'

export default function Diary({ p }: { p: Project }) {
  const { t } = useApp()
  return (
    <>
      <Header title={t('s.diary')} sub={t('di.sub')} />
      <div className="board">
        {p.board.map((c) => (
          <div className="col" key={c.title} style={cssVars({ '--d': c.color })}>
            <h3><i />{c.title}<em>{c.cards.length}</em></h3>
            {c.cards.map((card) => <div className="note" key={card}>{card}</div>)}
          </div>
        ))}
      </div>
    </>
  )
}
