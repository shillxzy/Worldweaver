import { useState } from 'react'
import { P } from '../icons'
import { useApp } from '../settings-context'

export default function Auth({ onEnter }: { onEnter: (name: string, email: string) => void }) {
  const { t } = useApp()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const enter = () => onEnter(name, email)

  return (
    <div className="auth">
      <div className="auth-art"><svg viewBox="0 0 24 24"><path d={P.logo} /></svg></div>
      <div className="auth-form">
        <div className="auth-box">
          <h1>{t('auth.title')}</h1>
          <p>{t('auth.sub')}</p>
          <input className="field" placeholder={t('auth.name')} value={name} onChange={(e) => setName(e.target.value)} />
          <input className="field" type="email" placeholder={t('auth.email')} value={email} onChange={(e) => setEmail(e.target.value)} />
          <input className="field" type="password" placeholder={t('auth.password')} />
          <button className="btn" onClick={enter}>{t('auth.enter')}</button>
          <button className="link" onClick={enter}>{t('auth.have')}</button>
        </div>
      </div>
    </div>
  )
}
