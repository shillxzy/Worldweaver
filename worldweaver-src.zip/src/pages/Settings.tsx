import { useState } from 'react'
import Header from '../components/Header'
import Icon from '../components/Icon'
import { useApp } from '../settings-context'
import type { Lang, Theme } from '../settings-context'

export default function Settings() {
  const { t, theme, setTheme, lang, setLang, deleteAccount } = useApp()
  const [confirm, setConfirm] = useState(false)

  const themes: { id: Theme; icon: 'moon' | 'sun' }[] = [{ id: 'dark', icon: 'moon' }, { id: 'light', icon: 'sun' }]
  const langs: { id: Lang; label: string }[] = [{ id: 'uk', label: 'Українська' }, { id: 'en', label: 'English' }]

  return (
    <>
      <Header title={t('st.title')} sub={t('st.sub')} />

      <section>
        <p className="label first">{t('st.appearance')}</p>
        <div className="panel">
          <div className="set-row">
            <div><h3>{t('st.theme')}</h3><p>{t('st.themeDesc')}</p></div>
            <div className="seg">
              {themes.map((o) => (
                <button key={o.id} className={theme === o.id ? 'on' : ''} onClick={() => setTheme(o.id)}>
                  <Icon n={o.icon} />{t('st.' + o.id)}
                </button>
              ))}
            </div>
          </div>
          <div className="set-row">
            <div><h3>{t('st.language')}</h3><p>{t('st.langDesc')}</p></div>
            <div className="seg">
              {langs.map((o) => (
                <button key={o.id} className={lang === o.id ? 'on' : ''} onClick={() => setLang(o.id)}>
                  {o.id === lang && <Icon n="globe" />}{o.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section>
        <p className="label first">{t('st.account')}</p>
        <div className="panel danger">
          <div className="set-row">
            <div><h3>{t('st.delete')}</h3><p>{t('st.deleteDesc')}</p></div>
            <button className="btn-danger" onClick={() => setConfirm(true)}><Icon n="trash" />{t('st.delete')}</button>
          </div>
        </div>
      </section>

      {confirm && (
        <div className="modal-back" onClick={() => setConfirm(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3 style={{ fontSize: 18 }}>{t('st.deleteTitle')}</h3>
            <p>{t('st.deleteText')}</p>
            <div className="acts">
              <button className="btn-ghost" onClick={() => setConfirm(false)}>{t('st.cancel')}</button>
              <button className="btn-danger" onClick={deleteAccount}>{t('st.confirm')}</button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
