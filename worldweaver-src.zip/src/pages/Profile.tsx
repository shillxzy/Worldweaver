import { useState } from 'react'
import Header from '../components/Header'
import Icon from '../components/Icon'
import { PROJECTS } from '../data/projects'
import { useApp } from '../settings-context'

export default function Profile() {
  const { t, user, setUser } = useApp()
  const [form, setForm] = useState(user)
  const [saved, setSaved] = useState(false)

  const books = PROJECTS.length
  const entries = PROJECTS.reduce((n, p) => n + p.entries.length, 0)
  const chars = PROJECTS.reduce((n, p) => n + p.entries.filter((e) => e.type === 'Персонаж').length, 0)

  const save = () => {
    setUser({ ...form, name: form.name.trim() || user.name })
    setSaved(true)
    setTimeout(() => setSaved(false), 1800)
  }

  return (
    <>
      <Header title={t('pr.title')} sub={t('pr.sub')} />
      <div className="me">
        <div className="av big">{user.name[0]?.toUpperCase()}</div>
        <div>
          <h3 style={{ fontSize: 20 }}>{user.name}</h3>
          <p>{user.email}</p>
          <div className="stats">
            <div><b>{books}</b><span>{t('pr.books')}</span></div>
            <div><b>{chars}</b><span>{t('pr.chars')}</span></div>
            <div><b>{entries}</b><span>{t('pr.entries')}</span></div>
          </div>
        </div>
      </div>
      <div className="form">
        <label>{t('pr.name')}<input className="field" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label>
        <label>{t('pr.email')}<input className="field" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label>
        <label>{t('pr.bio')}<textarea className="field" placeholder={t('pr.bioPh')} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} /></label>
        <div className="save-row">
          <button className="btn" onClick={save}>{t('pr.save')}</button>
          {saved && <span className="ok"><Icon n="check" />{t('pr.saved')}</span>}
        </div>
      </div>
    </>
  )
}
