import Header from '../components/Header'
import CoverArt from '../components/CoverArt'
import Icon from '../components/Icon'
import { PROJECTS } from '../data/projects'
import { navigate, projectPath } from '../router'
import { useApp } from '../settings-context'
import { accentVars } from '../utils'

export default function Library() {
  const { t } = useApp()
  return (
    <>
      <Header title={t('lib.title')} sub={t('lib.sub')} />
      <div className="books">
        {PROJECTS.map((p) => (
          <button key={p.id} className="bk" style={accentVars(p.accent)} onClick={() => navigate(projectPath(p.id))}>
            <div className="cover-art"><CoverArt p={p} big /></div>
            <div className="bk-info">
              <h3>{p.genre}</h3>
              <div className="bar"><i style={{ width: p.progress + '%' }} /></div>
              <div className="meta">
                <span><Icon n="users" />{p.entries.filter((e) => e.type === 'Персонаж').length}</span>
                <span><Icon n="encyclopedia" />{p.entries.length}</span>
                <span>{t('lib.read')} {p.progress}%</span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </>
  )
}
