import Header from '../components/Header'
import Icon from '../components/Icon'
import { useApp } from '../settings-context'
import type { Project } from '../types'
import { cssVars } from '../utils'

const hue = (s: string) => [...s].reduce((a, c) => a + c.charCodeAt(0) * 7, 0) % 360

export default function Characters({ p }: { p: Project }) {
  const { t } = useApp()
  return (
    <>
      <Header title={t('s.characters')} sub={`${t('ch.sub')} «${p.title}».`} />
      <div className="grid">
        {p.entries.filter((e) => e.type === 'Персонаж').map((c) => {
          const h = hue(c.name)
          return (
            <div className="char" key={c.name}>
              <div className="banner" style={{ background: `linear-gradient(135deg, hsl(${h} 45% 32%), hsl(${h + 50} 45% 14%))` }} />
              <div className="char-body">
                <div className="av" style={{ background: `hsl(${h} 45% 38%)` }}>{c.name.replace('Доктор ', '')[0]}</div>
                <h3>{c.name}</h3>
                <p>{c.desc}</p>
                {c.faction && <span className="tag" style={cssVars({ '--t': '#e879a8' })}><Icon n="shield" />{c.faction}</span>}
              </div>
            </div>
          )
        })}
      </div>
    </>
  )
}
