import CoverArt from '../components/CoverArt'
import Icon from '../components/Icon'
import { SECTIONS } from '../data/projects'
import { navigate, projectPath } from '../router'
import { useApp } from '../settings-context'
import type { Project } from '../types'

export default function Overview({ p }: { p: Project }) {
  const { t } = useApp()
  const chars = p.entries.filter((e) => e.type === 'Персонаж').length
  return (
    <>
      <div className="hero">
        <div className="cover-art"><CoverArt p={p} /></div>
        <div>
          <span className="tag">{p.genre}</span>
          <h1 style={{ marginTop: 10 }}>{p.title}</h1>
          <p className="sub">{p.desc}</p>
          <div className="stats">
            <div><b>{chars}</b><span>{t('ov.chars')}</span></div>
            <div><b>{p.entries.length}</b><span>{t('ov.entries')}</span></div>
            <div><b>{p.events.length}</b><span>{t('ov.events')}</span></div>
          </div>
        </div>
      </div>
      <div className="bento">
        {SECTIONS.slice(1).map((s, i) => (
          <button key={s.id} className={'tile' + (i === 0 || i === 4 ? ' wide' : '')} onClick={() => navigate(projectPath(p.id, s.id))}>
            <div className="chip"><Icon n={s.icon} /></div>
            <h3>{t('s.' + s.id)}</h3>
            <p>{t('d.' + s.id)}</p>
          </button>
        ))}
      </div>
    </>
  )
}
