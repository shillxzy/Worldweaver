export type Section = 'overview' | 'encyclopedia' | 'characters' | 'diary' | 'book' | 'timeline'
export type Entry = { name: string; type: string; desc: string; faction?: string }
export type Project = {
  id: string; title: string; genre: string; desc: string; accent: string; progress: number
  entries: Entry[]
  board: { title: string; color: string; cards: string[] }[]
  events: { date: string; title: string; text: string }[]
  pages: string[]
}
