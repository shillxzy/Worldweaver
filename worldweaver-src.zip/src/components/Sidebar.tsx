import { PROJECTS, SECTIONS } from '../data/projects'
import { navigate, projectPath } from '../router'
import type { Route } from '../router'
import { useApp } from '../settings-context'
import CoverArt from './CoverArt'
import Icon from './Icon'

export default function Sidebar({ route }: { route: Route }) {
  const { t, user, logout } = useApp()
  const project = route.page === 'project' ? route.project : undefined

  return (
    <aside className="sidebar">
      <div className="ws"><Icon n="logo" />Worldweaver</div>
      <div className="search"><Icon n="search" /><input className="field" placeholder={t('nav.search')} /></div>

      <p className="label">{t('nav.books')}</p>
      <button className={'nav' + (route.page === 'library' ? ' on' : '')} onClick={() => navigate('/')}>
        <Icon n="library" />{t('nav.allBooks')}
      </button>
      {PROJECTS.map((b) => (
        <button key={b.id} className={'nav' + (project?.id === b.id ? ' on' : '')} onClick={() => navigate(projectPath(b.id))}>
          <span className="cv"><CoverArt p={b} /></span>{b.title}
        </button>
      ))}

      {project && (
        <>
          <p className="label">{project.title}</p>
          {SECTIONS.map((s) => (
            <button
              key={s.id}
              className={'nav' + (route.page === 'project' && route.section === s.id ? ' on' : '')}
              onClick={() => navigate(projectPath(project.id, s.id))}
            >
              <Icon n={s.icon} />{t('s.' + s.id)}
            </button>
          ))}
        </>
      )}

      <div className="spacer" />
      <button className={'nav' + (route.page === 'settings' ? ' on' : '')} onClick={() => navigate('/settings')}>
        <Icon n="settings" />{t('nav.settings')}
      </button>
      <button className={'userchip' + (route.page === 'profile' ? ' on' : '')} onClick={() => navigate('/profile')}>
        <span className="av-sm">{user.name[0]?.toUpperCase()}</span>
        <span className="uc-text"><b>{user.name}</b><small>{user.email}</small></span>
      </button>
      <button className="nav" onClick={logout}><Icon n="logout" />{t('nav.logout')}</button>
    </aside>
  )
}
