import { PROJECTS } from './data/projects'
import { SECTIONS } from './data/projects'
import type { Project, Section } from './types'

export type Route =
  | { page: 'library' }
  | { page: 'profile' }
  | { page: 'settings' }
  | { page: 'project'; project: Project; section: Section }

export function parseHash(): Route {
  const [, a, id, sec] = location.hash.slice(1).split('/')
  if (a === 'profile') return { page: 'profile' }
  if (a === 'settings') return { page: 'settings' }
  const project = a === 'p' ? PROJECTS.find((x) => x.id === id) : undefined
  if (project) return { page: 'project', project, section: SECTIONS.find((s) => s.id === sec)?.id ?? 'overview' }
  return { page: 'library' }
}

export const navigate = (path: string) => { location.hash = path }
export const projectPath = (id: string, section: Section = 'overview') => `/p/${id}/${section}`
