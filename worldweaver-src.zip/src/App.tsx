import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import Sidebar from './components/Sidebar'
import { dict } from './i18n'
import { navigate, parseHash } from './router'
import type { Route } from './router'
import { AppContext } from './settings-context'
import type { Lang, Theme, User } from './settings-context'
import { accentVars } from './utils'
import Auth from './pages/Auth'
import Book from './pages/Book'
import Characters from './pages/Characters'
import Diary from './pages/Diary'
import Encyclopedia from './pages/Encyclopedia'
import Library from './pages/Library'
import Overview from './pages/Overview'
import Profile from './pages/Profile'
import Settings from './pages/Settings'
import Timeline from './pages/Timeline'

const EMPTY_USER: User = { name: '', email: '', bio: '' }

function stored<T extends string>(key: string, allowed: readonly T[], fallback: T): T {
  try {
    const v = localStorage.getItem(key) as T | null
    return v && allowed.includes(v) ? v : fallback
  } catch {
    return fallback
  }
}

function renderRoute(route: Route): ReactNode {
  switch (route.page) {
    case 'profile': return <Profile />
    case 'settings': return <Settings />
    case 'library': return <Library />
    case 'project': {
      const p = route.project
      switch (route.section) {
        case 'overview': return <Overview p={p} />
        case 'encyclopedia': return <Encyclopedia p={p} />
        case 'characters': return <Characters p={p} />
        case 'diary': return <Diary p={p} />
        case 'book': return <Book p={p} />
        case 'timeline': return <Timeline p={p} />
      }
    }
  }
}

export default function App() {
  const [authed, setAuthed] = useState(false)
  const [user, setUser] = useState<User>(EMPTY_USER)
  const [theme, setThemeState] = useState<Theme>(() => stored('ww-theme', ['dark', 'light'], 'dark'))
  const [lang, setLangState] = useState<Lang>(() => stored('ww-lang', ['uk', 'en'], 'uk'))
  const [route, setRoute] = useState<Route>(parseHash)

  useEffect(() => { document.documentElement.dataset.theme = theme }, [theme])
  useEffect(() => { document.documentElement.lang = lang }, [lang])
  useEffect(() => {
    const read = () => setRoute(parseHash())
    window.addEventListener('hashchange', read)
    return () => window.removeEventListener('hashchange', read)
  }, [])

  const setTheme = (v: Theme) => { setThemeState(v); try { localStorage.setItem('ww-theme', v) } catch { /* ignore */ } }
  const setLang = (v: Lang) => { setLangState(v); try { localStorage.setItem('ww-lang', v) } catch { /* ignore */ } }
  const t = (key: string) => dict[lang][key] ?? key

  const logout = () => { setAuthed(false); navigate('/') }
  const deleteAccount = () => { setUser(EMPTY_USER); logout() }

  const ctx = { theme, setTheme, lang, setLang, t, user, setUser, logout, deleteAccount }

  if (!authed) {
    return (
      <AppContext.Provider value={ctx}>
        <Auth onEnter={(name, email) => {
          setUser({ name: name.trim() || 'Автор', email: email.trim() || 'author@worldweaver.app', bio: '' })
          setAuthed(true)
        }} />
      </AppContext.Provider>
    )
  }

  const pageKey = route.page === 'project' ? route.project.id + route.section : route.page

  return (
    <AppContext.Provider value={ctx}>
      <div className="app" style={route.page === 'project' ? accentVars(route.project.accent) : undefined}>
        <Sidebar route={route} />
        <main className="main"><div className="page" key={pageKey}>{renderRoute(route)}</div></main>
      </div>
    </AppContext.Provider>
  )
}
