import { createContext, useContext } from 'react'

export type Theme = 'dark' | 'light'
export type Lang = 'uk' | 'en'
export type User = { name: string; email: string; bio: string }

export type AppCtx = {
  theme: Theme
  setTheme: (t: Theme) => void
  lang: Lang
  setLang: (l: Lang) => void
  t: (key: string) => string
  user: User
  setUser: (u: User) => void
  logout: () => void
  deleteAccount: () => void
}

export const AppContext = createContext<AppCtx | null>(null)

export function useApp(): AppCtx {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used inside AppContext.Provider')
  return ctx
}
